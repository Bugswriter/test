I couldn't the $2000$ map for CS:GO so I created it on my own.
I made this map using the original file from Calou and edited it for Counter-Strike : Global Offensive.

Install Notes:
1.Extract the .rar Archive
2.Copy the File to your /csgo/maps folder
3.Host either a Bot-Match or a private Game with any map
4.Open the console and type "changelevel $2000$_csgo"